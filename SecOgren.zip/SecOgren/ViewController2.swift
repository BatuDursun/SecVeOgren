//
//  ViewController2.swift
//  SecOgren
//
//  Created by Batu Dursun on 17.03.2024.
//

import UIKit

class ViewController2: UIViewController {

    
    @IBOutlet var button1:UIButton!
    @IBOutlet var button2:UIButton!
    @IBOutlet var button3:UIButton!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
}
