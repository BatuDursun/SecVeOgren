//
//  ViewController5.swift
//  SecOgren
//
//  Created by Batu Dursun on 17.03.2024.
//

import UIKit
import AVFoundation

class ViewController5: UIViewController {

    var audioPlayer: AVAudioPlayer?
    @IBOutlet var button1:UIButton!
    @IBOutlet var button2:UIButton!
    @IBOutlet var button3:UIButton!
    @IBOutlet var button4:UIButton!
    @IBOutlet var button5:UIButton!
    @IBOutlet var button6:UIButton!
    @IBOutlet var button7:UIButton!
    @IBOutlet var button8:UIButton!
    @IBOutlet var button9:UIButton!
    @IBOutlet var button10:UIButton!
    @IBOutlet var label:UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        label.text = ""
    }
    
    @IBAction func button1(_ sender:Any) {
        label.text = "SIFIR!"
        playSound(var: "SIFIR")
    }
    @IBAction func button2(_ sender:Any) {
        label.text = "BİR!"
        playSound(var: "BIR")
    }
    @IBAction func button3(_ sender:Any) {
        label.text = "İKİ!"
        playSound(var: "IKI")
    }
    @IBAction func button4(_ sender:Any) {
        label.text = "ÜÇ!"
        playSound(var: "UC")
    }
    @IBAction func button5(_ sender:Any) {
        label.text = "DÖRT!"
        playSound(var: "DORT")
    }
    @IBAction func button6(_ sender:Any) {
        label.text = "BEŞ!"
        playSound(var: "BES")
    }
    @IBAction func button7(_ sender:Any) {
        label.text = "ALTI!"
        playSound(var: "ALTI")
    }
    @IBAction func button8(_ sender:Any) {
        label.text = "YEDİ!"
        playSound(var: "YEDI")
    }
    @IBAction func button9(_ sender:Any) {
        label.text = "SEKİZ!"
        playSound(var: "SEKIZ")
    }
    @IBAction func button10(_ sender:Any) {
        label.text = "DOKUZ!"
        playSound(var: "DOKUZ")
    }
    
    
    func playSound(var soundResourceName:String) {
           guard let url = Bundle.main.url(forResource: soundResourceName, withExtension: "mp3") else { return }

           do {
               audioPlayer = try AVAudioPlayer(contentsOf: url)
               audioPlayer?.currentTime = 0 // Sesin başlangıç pozisyonunu belirle

               
               audioPlayer?.play()
               DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                   self.audioPlayer?.stop()
               }
           } catch {
               print("Ses dosyası çalınırken hata oluştu.")
           }
       }
    
    

}
