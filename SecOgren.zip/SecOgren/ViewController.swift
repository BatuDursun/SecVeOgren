//
//  ViewController.swift
//  SecOgren
//
//  Created by Batu Dursun on 17.03.2024.
//

import UIKit




class ViewController: UIViewController {
    
    @IBOutlet var button1:UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    
    
    @IBAction func button1(_ sender:Any) {

    }

   }


