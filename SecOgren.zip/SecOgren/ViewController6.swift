//
//  ViewController6.swift
//  SecOgren
//
//  Created by Batu Dursun on 22.03.2024.
//

import UIKit
import AVFoundation

class ViewController6: UIViewController {
    var audioPlayer: AVAudioPlayer?
    @IBOutlet var button1:UIButton!
    @IBOutlet var button2:UIButton!
    @IBOutlet var button3:UIButton!
    @IBOutlet var button4:UIButton!
    @IBOutlet var buttonSes:UIButton!
    
    @IBOutlet var barButton1:UIBarButtonItem!
    @IBOutlet var label1:UILabel!
    @IBOutlet var label2:UILabel!
    @IBOutlet var imageView:UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }

    
    
    @IBAction func button1(_ sender:Any){
        if label1.text == "SORU 4" || label1.text == "SORU 8"
        {
            imageView.image = UIImage(named: "tik")
        }
        else {
            imageView.image = UIImage(named: "cross")
        }
        
        if imageView.image == UIImage(named: "tik") {
            barButton1.isEnabled = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.imageView.image = nil
        }
    }
    @IBAction func button2(_ sender:Any){
        if label1.text == "SORU 3" || label1.text == "SORU 7"
        {
            imageView.image = UIImage(named: "tik")
        }
        else {
            imageView.image = UIImage(named: "cross")
        }
        if imageView.image == UIImage(named: "tik") {
            barButton1.isEnabled = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.imageView.image = nil
        }
    }
    @IBAction func button3(_ sender:Any){
        if label1.text == "SORU 2" || label1.text == "SORU 6" || label1.text == "SORU 10"
        {
            imageView.image = UIImage(named: "tik")
        }
        
        else {
            imageView.image = UIImage(named: "cross")
        }
        if imageView.image == UIImage(named: "tik") {
            barButton1.isEnabled = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.imageView.image = nil
        }
    }
    @IBAction func button4(_ sender:Any){
        if label1.text == "SORU 1" || label1.text == "SORU 5" || label1.text == "SORU 9"
        {
            
            imageView.image = UIImage(named: "tik")
        }
        
        else {
            imageView.image = UIImage(named: "cross")
        }
        
        if imageView.image == UIImage(named: "tik") {
            barButton1.isEnabled = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.imageView.image = nil
        }

    }
    
    
    @IBAction func buttonSes(_ sender:Any){
        
        if( label1.text == "SORU 1" ){
        playSound(var: "KIRMIZI")
        }
        else if
            ( label1.text == "SORU 2" ){
            playSound(var: "SARI")
        }
        else if
            ( label1.text == "SORU 3" ){
            playSound(var: "MOR")
        }
        else if
            ( label1.text == "SORU 4" ){
            playSound(var: "MAVI")
        }
        else if
            ( label1.text == "SORU 5" ){
            playSound(var: "TURUNCU")
        }
        else if
            ( label1.text == "SORU 6" ){
            playSound(var: "YEŞIL")
        }
        else if
            ( label1.text == "SORU 7" ){
            playSound(var: "BEYAZ")
        }
        else if
            ( label1.text == "SORU 8" ){
            playSound(var: "SIYAH")
        }
        else if
            ( label1.text == "SORU 9" ){
            playSound(var: "PEMBE")
        }
        else if
            ( label1.text == "SORU 10" ){
            playSound(var: "GRI")
        }
        
    }
    
    @IBAction func barButton1(_ sender:Any){
        imageView.image = nil
        if( label1.text == "SORU 1" ){
            
            label1.text = "SORU 2"
            label2.text = "Aşağıdakilerden hangisi sarı renktir ?"
            barButton1.isEnabled = false
            
            button1.backgroundColor = UIColor.systemGreen
            button2.backgroundColor = UIColor.systemGray
            button3.backgroundColor = UIColor.systemYellow
            button4.backgroundColor = UIColor.systemTeal
        }
        else if
            ( label1.text == "SORU 2" ){
            label1.text = "SORU 3"
            label2.text = "Aşağıdakilerden hangisi mor renktir ?"
            barButton1.isEnabled = false
            
            button1.backgroundColor = UIColor.systemPink
            button2.backgroundColor = UIColor.systemPurple
            button3.backgroundColor = UIColor.systemTeal
            button4.backgroundColor = UIColor.systemRed
        
        }
        else if
            ( label1.text == "SORU 3" ){
            label2.text = "Aşağıdakilerden hangisi mavi renktir ?"
            label1.text = "SORU 4"
            barButton1.isEnabled = false
            
            button1.backgroundColor = UIColor.systemTeal
            button2.backgroundColor = UIColor.systemGreen
            button3.backgroundColor = UIColor.systemOrange
            button4.backgroundColor = UIColor.systemYellow
        }
        else if
            ( label1.text == "SORU 4" ){
            label2.text = "Aşağıdakilerden hangisi turuncu renktir ?"
            label1.text = "SORU 5"
            barButton1.isEnabled = false
            
            button1.backgroundColor = UIColor.systemGray
            button2.backgroundColor = UIColor.systemRed
            button3.backgroundColor = UIColor.systemGreen
            button4.backgroundColor = UIColor.systemOrange
        }
        else if
            ( label1.text == "SORU 5" ){
            label2.text = "Aşağıdakilerden hangisi yeşil renktir ?"
            label1.text = "SORU 6"
            barButton1.isEnabled = false
            
            button1.backgroundColor = UIColor.systemPurple
            button2.backgroundColor = UIColor.systemPink
            button3.backgroundColor = UIColor.systemGreen
            button4.backgroundColor = UIColor.systemYellow
        }
        else if
            ( label1.text == "SORU 6" ){
            label2.text = "Aşağıdakilerden hangisi beyaz renktir ?"
            label1.text = "SORU 7"
            barButton1.isEnabled = false
            
            button1.backgroundColor = UIColor.systemOrange
            button2.backgroundColor = UIColor.white
            button3.backgroundColor = UIColor.black
            button4.backgroundColor = UIColor.systemGray
        }
        else if
            ( label1.text == "SORU 7" ){
            label2.text = "Aşağıdakilerden hangisi siyah renktir ?"
            label1.text = "SORU 8"
            barButton1.isEnabled = false
            
            button1.backgroundColor = UIColor.black
            button2.backgroundColor = UIColor.systemPink
            button3.backgroundColor = UIColor.systemRed
            button4.backgroundColor = UIColor.systemGreen
        }
        else if
            ( label1.text == "SORU 8" ){
            label2.text = "Aşağıdakilerden hangisi pembe renktir ?"
            label1.text = "SORU 9"
            barButton1.isEnabled = false
            
            button1.backgroundColor = UIColor.black
            button2.backgroundColor = UIColor.systemPurple
            button3.backgroundColor = UIColor.systemOrange
            button4.backgroundColor = UIColor.systemPink
        }
        else if
            ( label1.text == "SORU 9" ){
            label2.text = "Aşağıdakilerden hangisi gri renktir ?"
            label1.text = "SORU 10"
            barButton1.isEnabled = false
            barButton1.isHidden = true
            
            button1.backgroundColor = UIColor.systemTeal
            button2.backgroundColor = UIColor.white
            button3.backgroundColor = UIColor.systemGray
            button4.backgroundColor = UIColor.systemGreen
        }
        
    }
    
    
    func playSound(var soundResourceName:String) {
           guard let url = Bundle.main.url(forResource: soundResourceName, withExtension: "mp3") else { return }

           do {
               audioPlayer = try AVAudioPlayer(contentsOf: url)
               audioPlayer?.currentTime = 0 // Sesin başlangıç pozisyonunu belirle

               
               audioPlayer?.play()
               DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                   self.audioPlayer?.stop()
               }
           } catch {
               print("Ses dosyası çalınırken hata oluştu.")
           }
       }
    
}
