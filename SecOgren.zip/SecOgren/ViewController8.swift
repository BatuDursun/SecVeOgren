//
//  ViewController8.swift
//  SecOgren
//
//  Created by Batu Dursun on 22.03.2024.
//

import UIKit
import AVFoundation

class ViewController8: UIViewController {
    
    var audioPlayer: AVAudioPlayer?
    @IBOutlet var button1:UIButton!
    @IBOutlet var button2:UIButton!
    @IBOutlet var button3:UIButton!
    @IBOutlet var button4:UIButton!
    @IBOutlet var buttonSes:UIButton!

    @IBOutlet var barButton1:UIBarButtonItem!
    @IBOutlet var label1:UILabel!
    @IBOutlet var label2:UILabel!
    @IBOutlet var imageView:UIImageView!
    
    @IBOutlet var imageView1:UIImageView!
    @IBOutlet var imageView2:UIImageView!
    @IBOutlet var imageView3:UIImageView!
    @IBOutlet var imageView4:UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

     
        
    }
    @IBAction func button1(_ sender:Any){
        if label1.text == "SORU 4" || label1.text == "SORU 8"
        {
            imageView.image = UIImage(named: "tik")
        }
        else {
            imageView.image = UIImage(named: "cross")
        }
        
        if imageView.image == UIImage(named: "tik") {
            barButton1.isEnabled = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.imageView.image = nil
        }
    }
    @IBAction func button2(_ sender:Any){
        if label1.text == "SORU 3" || label1.text == "SORU 7"
        {
            imageView.image = UIImage(named: "tik")
        }
        else {
            imageView.image = UIImage(named: "cross")
        }
        if imageView.image == UIImage(named: "tik") {
            barButton1.isEnabled = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.imageView.image = nil
        }
    }
    @IBAction func button3(_ sender:Any){
        if label1.text == "SORU 2" || label1.text == "SORU 6" || label1.text == "SORU 10"
        {
            imageView.image = UIImage(named: "tik")
        }
        
        else {
            imageView.image = UIImage(named: "cross")
        }
        if imageView.image == UIImage(named: "tik") {
            barButton1.isEnabled = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.imageView.image = nil
        }
    }
    @IBAction func button4(_ sender:Any){
        if label1.text == "SORU 1" || label1.text == "SORU 5" || label1.text == "SORU 9"
        {
            
            imageView.image = UIImage(named: "tik")
        }
        
        else {
            imageView.image = UIImage(named: "cross")
        }
        
        if imageView.image == UIImage(named: "tik") {
            barButton1.isEnabled = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.imageView.image = nil
        }
    }
    @IBAction func buttonSes(_ sender:Any){
        
        if( label1.text == "SORU 1" ){
        playSound(var: "ALTI")
        }
        else if
            ( label1.text == "SORU 2" ){
            playSound(var: "BES")
        }
        else if
            ( label1.text == "SORU 3" ){
            playSound(var: "BIR")
        }
        else if
            ( label1.text == "SORU 4" ){
            playSound(var: "DOKUZ")
        }
        else if
            ( label1.text == "SORU 5" ){
            playSound(var: "UC")
        }
        else if
            ( label1.text == "SORU 6" ){
            playSound(var: "YEDI")
        }
        else if
            ( label1.text == "SORU 7" ){
            playSound(var: "IKI")
        }
        else if
            ( label1.text == "SORU 8" ){
            playSound(var: "SIFIR")
        }
        else if
            ( label1.text == "SORU 9" ){
            playSound(var: "DORT")
        }
        else if
            ( label1.text == "SORU 10" ){
            playSound(var: "SEKIZ")
        }
        
    }
    @IBAction func barButton1(_ sender:Any){
        imageView.image = nil
        if( label1.text == "SORU 1" ){
            
            label1.text = "SORU 2"
            label2.text = "Aşağıdakilerden hangisi beştir ?"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "YEDI")
            imageView2.image = UIImage(named: "SIFIR")
            imageView3.image = UIImage(named: "BES")
            imageView4.image = UIImage(named: "IKI")
                
            
        }
        else if
            ( label1.text == "SORU 2" ){
            label1.text = "SORU 3"
            label2.text = "Aşağıdakilerden hangisi birdir ?"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "ALTI")
            imageView2.image = UIImage(named: "BIR")
            imageView3.image = UIImage(named: "DORT")
            imageView4.image = UIImage(named: "UC")
        
        }
        else if
            ( label1.text == "SORU 3" ){
            label2.text = "Aşağıdakilerden hangisi dokuzdur ?"
            label1.text = "SORU 4"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "DOKUZ")
            imageView2.image = UIImage(named: "IKI")
            imageView3.image = UIImage(named: "YEDI")
            imageView4.image = UIImage(named: "ALTI")
        }
        else if
            ( label1.text == "SORU 4" ){
            label2.text = "Aşağıdakilerden hangisi üçtür ?"
            label1.text = "SORU 5"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "BIR")
            imageView2.image = UIImage(named: "SEKIZ")
            imageView3.image = UIImage(named: "SIFIR")
            imageView4.image = UIImage(named: "UC")
        }
        else if
            ( label1.text == "SORU 5" ){
            label2.text = "Aşağıdakilerden hangisi yedidir ?"
            label1.text = "SORU 6"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "DOKUZ")
            imageView2.image = UIImage(named: "DORT")
            imageView3.image = UIImage(named: "YEDI")
            imageView4.image = UIImage(named: "ALTI")
        }
        else if
            ( label1.text == "SORU 6" ){
            label2.text = "Aşağıdakilerden hangisi ikidir ?"
            label1.text = "SORU 7"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "SIFIR")
            imageView2.image = UIImage(named: "IKI")
            imageView3.image = UIImage(named: "SEKIZ")
            imageView4.image = UIImage(named: "UC")
        }
        else if
            ( label1.text == "SORU 7" ){
            label2.text = "Aşağıdakilerden hangisi sıfırdır ?"
            label1.text = "SORU 8"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "SIFIR")
            imageView2.image = UIImage(named: "DORT")
            imageView3.image = UIImage(named: "BES")
            imageView4.image = UIImage(named: "DOKUZ")
        }
        else if
            ( label1.text == "SORU 8" ){
            label2.text = "Aşağıdakilerden hangisi dörttür ?"
            label1.text = "SORU 9"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "IKI")
            imageView2.image = UIImage(named: "SIFIR")
            imageView3.image = UIImage(named: "ALTI")
            imageView4.image = UIImage(named: "DORT")
        }
        else if
            ( label1.text == "SORU 9" ){
            label2.text = "Aşağıdakilerden hangisi sekizdir ?"
            label1.text = "SORU 10"
            barButton1.isEnabled = false
            barButton1.isHidden = true
            
            imageView1.image = UIImage(named: "BIR")
            imageView2.image = UIImage(named: "SIFIR")
            imageView3.image = UIImage(named: "SEKIZ")
            imageView4.image = UIImage(named: "YEDI")
        }
        
    }
    

    

    func playSound(var soundResourceName:String) {
           guard let url = Bundle.main.url(forResource: soundResourceName, withExtension: "mp3") else { return }

           do {
               audioPlayer = try AVAudioPlayer(contentsOf: url)
               audioPlayer?.currentTime = 0 // Sesin başlangıç pozisyonunu belirle

               
               audioPlayer?.play()
               DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                   self.audioPlayer?.stop()
               }
           } catch {
               print("Ses dosyası çalınırken hata oluştu.")
           }
       }
    
}
