//
//  ViewController3.swift
//  SecOgren
//
//  Created by Batu Dursun on 17.03.2024.
//

import UIKit
import AVFoundation

class ViewController3: UIViewController {
    var audioPlayer: AVAudioPlayer?
    @IBOutlet var button1:UIButton!
    @IBOutlet var button2:UIButton!
    @IBOutlet var button3:UIButton!
    @IBOutlet var button4:UIButton!
    @IBOutlet var button5:UIButton!
    @IBOutlet var button6:UIButton!
    @IBOutlet var button7:UIButton!
    @IBOutlet var button8:UIButton!
    @IBOutlet var button9:UIButton!
    @IBOutlet var button10:UIButton!
    @IBOutlet var label:UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        label.text = ""
    }
    
    
    
    @IBAction func button1(_ sender:Any) {
        label.text = "SARI!"
        label.textColor = .yellow
        playSound(var: "SARI")
    }
    @IBAction func button2(_ sender:Any) {
        label.text = "KIRMIZI!"
        label.textColor = .red
        playSound(var: "KIRMIZI")
        
    }
    @IBAction func button3(_ sender:Any) {
        label.text = "MAVİ!"
        label.textColor = .systemTeal
        playSound(var: "MAVI")
    }
    @IBAction func button4(_ sender:Any) {
        label.text = "MOR!"
        label.textColor = .purple
        playSound(var: "MOR")
    }
    @IBAction func button5(_ sender:Any) {
        label.text = "YEŞİL!"
        label.textColor = .systemGreen
        playSound(var: "YEŞIL")
    }
    @IBAction func button6(_ sender:Any) {
        label.text = "TURUNCU!"
        label.textColor = .systemOrange
        playSound(var: "TURUNCU")
    }
    @IBAction func button7(_ sender:Any) {
        label.text = "SİYAH!"
        label.textColor = .black
        playSound(var:"SIYAH")
    }
    @IBAction func button8(_ sender:Any) {
        label.text = "BEYAZ!"
        label.textColor = .white
        playSound(var: "BEYAZ")
    }
    @IBAction func button9(_ sender:Any) {
        label.text = "GRİ!"
        label.textColor = .gray
        playSound(var: "GRI")
    }
    @IBAction func button10(_ sender:Any) {
        label.text = "PEMBE!"
        label.textColor = .systemPink
        playSound(var: "PEMBE")
    }

    
    func playSound(var soundResourceName:String) {
           guard let url = Bundle.main.url(forResource: soundResourceName, withExtension: "mp3") else { return }

           do {
               audioPlayer = try AVAudioPlayer(contentsOf: url)
               audioPlayer?.currentTime = 0 // Sesin başlangıç pozisyonunu belirle

               
               audioPlayer?.play()
               DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                   self.audioPlayer?.stop()
               }
           } catch {
               print("Ses dosyası çalınırken hata oluştu.")
           }
       }
    
}
