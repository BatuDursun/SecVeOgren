//
//  ViewController7.swift
//  SecOgren
//
//  Created by Batu Dursun on 22.03.2024.
//

import UIKit
import AVFoundation

class ViewController7: UIViewController {

    
    var audioPlayer: AVAudioPlayer?
    @IBOutlet var button1:UIButton!
    @IBOutlet var button2:UIButton!
    @IBOutlet var button3:UIButton!
    @IBOutlet var button4:UIButton!
    @IBOutlet var buttonSes:UIButton!
    
    
    @IBOutlet var barButton1:UIBarButtonItem!
    @IBOutlet var label1:UILabel!
    @IBOutlet var label2:UILabel!
    @IBOutlet var imageView:UIImageView!
    
    @IBOutlet var imageView1:UIImageView!
    @IBOutlet var imageView2:UIImageView!
    @IBOutlet var imageView3:UIImageView!
    @IBOutlet var imageView4:UIImageView!

    

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func button1(_ sender:Any){
        if label1.text == "SORU 4" || label1.text == "SORU 8"
        {
            imageView.image = UIImage(named: "tik")
        }
        else {
            imageView.image = UIImage(named: "cross")
        }
        
        if imageView.image == UIImage(named: "tik") {
            barButton1.isEnabled = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.imageView.image = nil
        }
    }
    @IBAction func button2(_ sender:Any){
        if label1.text == "SORU 3" || label1.text == "SORU 7"
        {
            imageView.image = UIImage(named: "tik")
        }
        else {
            imageView.image = UIImage(named: "cross")
        }
        if imageView.image == UIImage(named: "tik") {
            barButton1.isEnabled = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.imageView.image = nil
        }
    }
    @IBAction func button3(_ sender:Any){
        if label1.text == "SORU 2" || label1.text == "SORU 6" || label1.text == "SORU 10"
        {
            imageView.image = UIImage(named: "tik")
        }
        
        else {
            imageView.image = UIImage(named: "cross")
        }
        if imageView.image == UIImage(named: "tik") {
            barButton1.isEnabled = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.imageView.image = nil
        }
    }
    @IBAction func button4(_ sender:Any){
        if label1.text == "SORU 1" || label1.text == "SORU 5" || label1.text == "SORU 9"
        {
            
            imageView.image = UIImage(named: "tik")
        }
        
        else {
            imageView.image = UIImage(named: "cross")
        }
        
        if imageView.image == UIImage(named: "tik") {
            barButton1.isEnabled = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.imageView.image = nil
        }
    }
    
    @IBAction func buttonSes(_ sender:Any){
        
        if( label1.text == "SORU 1" ){
        playSound(var: "KEDI")
        }
        else if
            ( label1.text == "SORU 2" ){
            playSound(var: "inek")
        }
        else if
            ( label1.text == "SORU 3" ){
            playSound(var: "ASLAN")
        }
        else if
            ( label1.text == "SORU 4" ){
            playSound(var: "AT")
        }
        else if
            ( label1.text == "SORU 5" ){
            playSound(var: "KOYUN")
        }
        else if
            ( label1.text == "SORU 6" ){
            playSound(var: "KUS")
        }
        else if
            ( label1.text == "SORU 7" ){
            playSound(var: "ORDEK")
        }
        else if
            ( label1.text == "SORU 8" ){
            playSound(var: "TAVUK")
        }
        else if
            ( label1.text == "SORU 9" ){
            playSound(var: "MAYMUN")
        }
        else if
            ( label1.text == "SORU 10" ){
            playSound(var: "KOPEK")
        }
        
    }

    @IBAction func barButton1(_ sender:Any){
        imageView.image = nil
        if( label1.text == "SORU 1" ){
            
            label1.text = "SORU 2"
            label2.text = "Aşağıdakilerden hangisi inektir ?"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "tavuk")
            imageView2.image = UIImage(named: "ordek")
            imageView3.image = UIImage(named: "ınek")
            imageView4.image = UIImage(named: "maymun")
                
            
        }
        else if
            ( label1.text == "SORU 2" ){
            label1.text = "SORU 3"
            label2.text = "Aşağıdakilerden hangisi aslandır ?"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "at")
            imageView2.image = UIImage(named: "aslan")
            imageView3.image = UIImage(named: "kus")
            imageView4.image = UIImage(named: "koyun")
        
        }
        else if
            ( label1.text == "SORU 3" ){
            label2.text = "Aşağıdakilerden hangisi attır ?"
            label1.text = "SORU 4"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "at")
            imageView2.image = UIImage(named: "ordek")
            imageView3.image = UIImage(named: "ınek")
            imageView4.image = UIImage(named: "tavuk")
        }
        else if
            ( label1.text == "SORU 4" ){
            label2.text = "Aşağıdakilerden hangisi koyundur ?"
            label1.text = "SORU 5"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "kopek")
            imageView2.image = UIImage(named: "ordek")
            imageView3.image = UIImage(named: "kus")
            imageView4.image = UIImage(named: "koyun")
        }
        else if
            ( label1.text == "SORU 5" ){
            label2.text = "Aşağıdakilerden hangisi kuştur ?"
            label1.text = "SORU 6"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "maymun")
            imageView2.image = UIImage(named: "aslan")
            imageView3.image = UIImage(named: "kus")
            imageView4.image = UIImage(named: "tavuk")
        }
        else if
            ( label1.text == "SORU 6" ){
            label2.text = "Aşağıdakilerden hangisi ördektir ?"
            label1.text = "SORU 7"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "kopek")
            imageView2.image = UIImage(named: "ordek")
            imageView3.image = UIImage(named: "kedi")
            imageView4.image = UIImage(named: "ınek")
        }
        else if
            ( label1.text == "SORU 7" ){
            label2.text = "Aşağıdakilerden hangisi tavuktur ?"
            label1.text = "SORU 8"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "tavuk")
            imageView2.image = UIImage(named: "aslan")
            imageView3.image = UIImage(named: "at")
            imageView4.image = UIImage(named: "kedi")
        }
        else if
            ( label1.text == "SORU 8" ){
            label2.text = "Aşağıdakilerden hangisi maymundur ?"
            label1.text = "SORU 9"
            barButton1.isEnabled = false
            
            imageView1.image = UIImage(named: "kus")
            imageView2.image = UIImage(named: "ınek")
            imageView3.image = UIImage(named: "koyun")
            imageView4.image = UIImage(named: "maymun")
        }
        else if
            ( label1.text == "SORU 9" ){
            label2.text = "Aşağıdakilerden hangisi köpektir ?"
            label1.text = "SORU 10"
            barButton1.isEnabled = false
            barButton1.isHidden = true
            
            imageView1.image = UIImage(named: "aslan")
            imageView2.image = UIImage(named: "ordek")
            imageView3.image = UIImage(named: "kopek")
            imageView4.image = UIImage(named: "ınek")
        }
        
    }
    
    func playSound(var soundResourceName:String) {
           guard let url = Bundle.main.url(forResource: soundResourceName, withExtension: "mp3") else { return }

           do {
               audioPlayer = try AVAudioPlayer(contentsOf: url)
               audioPlayer?.currentTime = 0 // Sesin başlangıç pozisyonunu belirle

               
               audioPlayer?.play()
               DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                   self.audioPlayer?.stop()
               }
           } catch {
               print("Ses dosyası çalınırken hata oluştu.")
           }
       }
    
}
